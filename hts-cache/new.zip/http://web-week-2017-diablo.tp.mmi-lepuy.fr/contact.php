
<!DOCTYPE html> 
<html lang="fr">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Nous contacter</title>

        <!--INCLUDES STYLESHEETS-->
        <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.min.css" /> 
        <link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-theme.css"/>        
        <link rel="stylesheet" type="text/css" href="css/swiper/swiper.css" />
        <link rel="stylesheet" type="text/css" href="css/swiper/swiper.min.css" />
        <link rel="stylesheet" type="text/css" href="css/font-awesome-4.7.0/css/font-awesome.min.css"/>
        <link rel="stylesheet" type="text/css" href="css/simple-line-icons.css"/>

        <!--CUSTOM STYLESHEETS-->
        <link rel="stylesheet" type="text/css" href="css/style-chloeB.css" />
        <link rel="stylesheet" type="text/css" href="css/style-font.css" />

        <!--INCLUDES SCRIPTS-->
        <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script src="js/swiper/swiper.js"></script>

    </head>

    <body class="">

        <div class="container-fluid">
            <div class="row navbar">
                <div class="col-xs-6 col-md-4 brand">
                    <a href="index.php"><i class=""></i></a>
                </div>

                <i class="icon-menu hide-md-bef col-xs-6 text-right" id="menu-trig"></i>

                <ul class="col-xs-12 col-md-8 menu-wrapper">
                                        <li>
                        <a href="index.php" class="text-uppercase"><span><i class="icon-home" aria-hidden="true"></i></span>Accueil</a>
                    </li>
                                        <li>
                        <a href="search.php" class="text-uppercase"><span><i class="icon-compass" aria-hidden="true"></i></span>Toutes nos formules</a>
                    </li>
                                        <li>
                        <a href="contact.php" class="text-uppercase"><span><i class="icon-envelope" aria-hidden="true"></i></span>Contact</a>
                    </li>
                                        <li>
                        <a href="admin/" class="text-uppercase"><span><i class="icon-user" aria-hidden="true"></i></span>Admin</a>
                    </li>
                                    </ul>
            </div>
        </div>

            
    <body class="page-contact container-fluid">
        
        
    <!-- NAVBAR -->
        <div class="row">
        <div class="col-md-12 navbar"></div>
        </div>
     <!-- FORMULAIRE -->
        <div class="row">
        <div class="container">
            <div class="col-xs-offset-1">
                <h3>Besoin d’un renseignement ? Envoyez-nous un message !</h3>
            </div>
            <div class="col-md-7 col-xs-offset-1 col-xs-11 box-shadow formulaire">
                <div class="col-md-7 col-xs-8">
                    <form action="/ma-page-de-traitement" method="post">
                        <div>
                            <p>Votre nom</p>
                            <input type="text" id="nom" class="box-answer" />
                        </div>
                        <div>
                            <p>Votre adresse email</p>
                            <input type="email" id="courriel" class="box-answer" />
                        </div>
                        <div>
                            <p>Message</p>
                            <textarea id="message" rows="6" class="box-answer"></textarea>
                        </div>
                        <button type="button" class="btn btn-vert"><i class="fa fa-paper-plane-o" aria-hidden="true"></i> envoyer</button>
                    </form>
                </div>
                
                <div class="col-md-5 col-xs-4 photo">
                    
                    <!-- Image en background dans le CSS -->
                </div>
            </div>
        </div>
        </div>
        
        <!-- FOOTER -->
        <div class="row">
            <div class="col-xs-12 footer">
                <div class="row">
                    <div class="col-xs-offset-1 col-xs-4">
                        <h4>ALTI'UDE</h4>
                        <p>Et olim licet otiosae sint tribus pacataeque centuriae et nulla suffragiorum certamina set Pompiliani redierit securitas temporis, per omnes tamen quotquot sunt partes terrarum, ut domina sm eomnes tamen quotquot st vt otiosae sint tribus perecundum.</p>
                    </div>
                
                    <div class="col-md-offset-2 col-md-2 col-xs-offset-0 col-xs-4">
                        <h4>CONTACT</h4>
                        <p>4 rues des Lauriers <br>43 000 Le Puy en Velay</p>
                        <p>04 05 06 07 08 </p>
                        <p>alti’ude@contact.fr</p</p>
                    </div>
                
                    <div class="col-md-offset-1 col-md-1 col-xs-offset-0 col-xs-1">
                        <a href="#"><i class="fa fa-facebook-square fa-1x social-media" aria-hidden="true"></i></a><br>
                        <a href="#"><i class="fa fa-twitter fa-1x social-media" aria-hidden="true"></i></a><br>
                        <a href="#"><i class="fa fa-instagram fa-1x social-media" aria-hidden="true"></i></a>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-1 col-md-offset-10 col-xs-3 col-xs-offset-9 copyright">
                    <p>2017 - Alti’ude ©</p>
                    </div>
                </div>
            </div> 
        </div>
        
        <!-- /FOOTER -->
        
    </body>
</html>