<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Administration</title>

    <!-- Icons -->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/simple-line-icons.css" rel="stylesheet">

    <!-- Main styles for this application -->
    <link href="css/style.css" rel="stylesheet">
    <!-- Styles required by this views -->
    <link href="../css/admin.css" rel="stylesheet">
    
    <script src="../js/jquery.min.js"></script>
    
    
</head> 
  
<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
        <!--HEADER-->
        <header class="app-header navbar ">
            <button class="navbar-toggler mobile-sidebar-toggler d-lg-none mr-auto" type="button">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler sidebar-toggler d-md-down-none" type="button">
                <span class="navbar-toggler-icon"></span>
            </button>

            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item d-md-down-none">
                    Bonjour, John Doe                </li>
                <li class="nav-item d-md-down-none">
                    <a class="nav-link loggout-btn" href="#"><i class="icon-logout"></i> Se déconnecter </a>
                </li>
            </ul>
        </header>
        <!--/HEADER-->
   
    

        <!--BODY-->
        <div class="app-body">
           
            <div class="sidebar">
                <!--MENU SIDEBAR-->
                 
<nav class="sidebar-nav">
    <ul class="nav">
                <li class="nav-item">
            <a class="nav-link active" href="index.php"><i class="icon-speedometer"></i> Accueil</a>
        </li>
                <li class="nav-title">
            Contenu        </li>
                <li class="nav-item nav-dropdown">
            <a class="nav-link nav-dropdown-toggle " href="#"><i class="icon-doc"></i> Pages</a>
            
            <ul class="nav-dropdown-items">
                                <li class="nav-item">
                    <a class="nav-link " href="pages/edit-page.php?state=new"><i class="icon-plus"></i> Créer une page</a>
                </li>
                                <li class="nav-item">
                    <a class="nav-link " href="pages/list-page.php"><i class="icon-eye"></i> Voir les pages</a>
                </li>
                            </ul>
        </li>
                <li class="nav-item">
            <a class="nav-link " href="pages/image-uploader-page.php"><i class="icon-picture"></i> Ajouter/Supprimer des images</a>
        </li>
                <li class="nav-item nav-dropdown">
            <a class="nav-link nav-dropdown-toggle " href="#"><i class="icon-drawer"></i> Catégories</a>
            
            <ul class="nav-dropdown-items">
                                <li class="nav-item">
                    <a class="nav-link " href="cat/edit-cat.php?state=new"><i class="icon-plus"></i> Créer une catégorie</a>
                </li>
                                <li class="nav-item">
                    <a class="nav-link " href="cat/list-cat.php"><i class="icon-eye"></i> Voir les catégories</a>
                </li>
                            </ul>
        </li>
            </ul>
</nav>   
<button class="sidebar-minimizer brand-minimizer" type="button"></button>    
    
                <!--MENU SIDEBAR-->
            </div>

            <!-- Main content -->
            <main class="main">

                <!--MAIN CONTENTE AREA-->
                <div class="container-fluid">
                    <div class="animated fadeIn">
                        
                        <div class="card mt-5">
                           <div class="card-body">
                               
                               <div class="row">
                                   
                                    <div class="col-12">
                                        <h4 class="card-title">Administration - Alti'ude</h4>
                                    </div>
                                   
                               </div>
                               
                           </div>
                            
                            
                            
                        </div>
                        
                        
                    </div>
                </div>
                <!-- /.conainer-fluid -->
                
            </main>

        </div>
        

        <footer class="app-footer">
            <span><a href="http://coreui.io">CoreUI</a> © 2017 creativeLabs.</span>
            <span class="ml-auto">Powered by <a href="http://coreui.io">CoreUI</a></span>
        </footer>

        <!-- Bootstrap and necessary plugins -->
        <script src="../js/popper.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/pace.min.js"></script>

        <!-- CoreUI main scripts -->

        <script src="js/app.js"></script>

        <!-- Plugins and scripts required by this views -->


    </body>
</html>

