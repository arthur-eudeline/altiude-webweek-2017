<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Pages du site</title>

    <!-- Icons -->
    <link href="../../css/font-awesome.min.css" rel="stylesheet">
    <link href="../../css/simple-line-icons.css" rel="stylesheet">

    <!-- Main styles for this application -->
    <link href="../css/style.css" rel="stylesheet">
    <!-- Styles required by this views -->
    <link href="../../css/admin.css" rel="stylesheet">
    
    <script src="../../js/jquery.min.js"></script>
    
    
</head> 
  
<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
        <!--HEADER-->
        <header class="app-header navbar ">
            <button class="navbar-toggler mobile-sidebar-toggler d-lg-none mr-auto" type="button">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler sidebar-toggler d-md-down-none" type="button">
                <span class="navbar-toggler-icon"></span>
            </button>

            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item d-md-down-none">
                    Bonjour, John Doe                </li>
                <li class="nav-item d-md-down-none">
                    <a class="nav-link loggout-btn" href="#"><i class="icon-logout"></i> Se déconnecter </a>
                </li>
            </ul>
        </header>
        <!--/HEADER-->
   
    

        <!--BODY-->
        <div class="app-body">
           
            <div class="sidebar">
                <!--MENU SIDEBAR-->
                 
<nav class="sidebar-nav">
    <ul class="nav">
                <li class="nav-item">
            <a class="nav-link " href="../index.php"><i class="icon-speedometer"></i> Accueil</a>
        </li>
                <li class="nav-title">
            Contenu        </li>
                <li class="nav-item nav-dropdown">
            <a class="nav-link nav-dropdown-toggle " href="#"><i class="icon-doc"></i> Pages</a>
            
            <ul class="nav-dropdown-items">
                                <li class="nav-item">
                    <a class="nav-link " href="../pages/edit-page.php?state=new"><i class="icon-plus"></i> Créer une page</a>
                </li>
                                <li class="nav-item">
                    <a class="nav-link " href="../pages/list-page.php"><i class="icon-eye"></i> Voir les pages</a>
                </li>
                            </ul>
        </li>
                <li class="nav-item">
            <a class="nav-link " href="../pages/image-uploader-page.php"><i class="icon-picture"></i> Ajouter/Supprimer des images</a>
        </li>
                <li class="nav-item nav-dropdown">
            <a class="nav-link nav-dropdown-toggle " href="#"><i class="icon-drawer"></i> Catégories</a>
            
            <ul class="nav-dropdown-items">
                                <li class="nav-item">
                    <a class="nav-link " href="../cat/edit-cat.php?state=new"><i class="icon-plus"></i> Créer une catégorie</a>
                </li>
                                <li class="nav-item">
                    <a class="nav-link " href="../cat/list-cat.php"><i class="icon-eye"></i> Voir les catégories</a>
                </li>
                            </ul>
        </li>
            </ul>
</nav>   
<button class="sidebar-minimizer brand-minimizer" type="button"></button>    
    
                <!--MENU SIDEBAR-->
            </div>

            <!-- Main content -->
            <main class="main">
               
                <!--MAIN CONTENTE AREA-->
                <div class="container-fluid">
                    <div class="animated fadeIn">
                        
                        <div class="card mt-5">
                          <div class="card-header">
                                <div class="row">
                                    <div class="col-md-8 col-xs-12 pull-md-4">
                                        <h4 class="card-title">Pages </h4>
                                    </div>

                                    <div class="col-md-4 col-xs-12 push-md-8 text-right">
                                        <a href="edit-page.php?state=new" class="secondary-outline-btn custom-btn">Ajouter une page</a>
                                    </div>
                              </div>
                          </div>
                          
                           <div class="card-body">
                               
                                                              <div class="row mb-2 mt-2">
                                   
                                    <div class="col-12 col-md-8">
                                        <h2>LE PUY-EN-VELAY, SITE EXCEPTIONNEL </h2>
                                        <p>Le site exceptionnel du Puy-en-Velay et sa cathédrale classée au Patrimoine Mondial de l’humanité par l’UNESCO, enchâssés dans un cadre verdoyant de montagnes volcaniques où l’eau et le feu ont sculpté des décors naturels et où l’homme a fait triompher la beauté de l’art.
Cette œuvre monumentale en fonte de fer est située dans la ville du Puy-en-Velay. Construite entre 1856 et 1860, à partir de canons sur les plans de Jean-Marie Bonnassieux. La statue se situe à 757 mètres d'altitude, au sommet du « rocher Corneille » La statue représente la Vierge Marie couronnée d'étoiles, se tenant debout sur un demi globe terrestre où elle écrase du pied un serpent, et tenant sur son bras droit l'Enfant Jésus qui bénit la ville et la France . Elle mesure plus de 16 mètres et sa masse totale est estimée à 835 tonnes. Un escalier de pierre composé de 33 marches est aménagé dans le piédestal et permet d'accéder à l'intérieur de la statue qui est creux  .
Quant à elle, la cathédrale Notre-Dame de l'Annonciation est un monument majeur de l'art roman et de l'Occident chrétien.  Une Vierge noire, objet de nombreux pèlerinages au cours des siècles,aurait été offerte par Saint Louis à son retour de la croisade d’Égypte . Elle fut brûlée lors de la révolution mais as été remplacée.La cathédrale a été élue 2e monument préféré des français en 2015 . Un dolmen occupe depuis des millénaires l'actuelle emplacement de la cathédrale. appelé pierre des apparitions C'est sur ce dolmen que serait apparue au iiie siècle la Vierge à une matrone du Puy . D'autres apparitions ont étaient recensées depuis. Cette pierre marqué a l'origine le temps qui ce dressé la auparavent: Un temples pour le dieu gaulois cernunnos. L'emplacement referme dés lors nombres de mystère.</p>
                                    </div>
                                    
                                    <div class="col-12 col-md-4 text-md-right">
                                        <a href="edit-page.php?state=edit&page-id=11" class="primary-outline-btn custom-btn mt-1 mb-2">Éditer la page  <i class="icon-pencil"></i></a>
                                        <a href="../../formule.php?page-id=11" class="secondary-outline-btn custom-btn mt-1 mb-2">Voir la page <i class="icon-eye"></i></a>
                                    </div>    
                                    
 
                               </div>
                                                              <div class="row mb-2 mt-2">
                                   
                                    <div class="col-12 col-md-8">
                                        <h2>LES THERMES</h2>
                                        <p>Dans la commune de Félines se trouve un petit village particulier en Haute-Loire: La Souchère. Ce petit hameau abrité jusqu’à la fin de la seconde guerre mondiale une source thermal unique dans le département. Les eaux de la Souchére, reconnue eau minérale, appartenait à la famille Ligonie. L'établissement autrefois imposant est désormais réduit à quelques ruines et décombres mais témoigne d'un passé glorieux via les nombreuses cartes postales que les locaux possèdent toujours. Cette source date de 1772 et a été recensé sur l'ordre du roi louis XV. Ce bâtiment, ces vestiges et les documents relatifs à cette époque nous depeins une époque que personne n'a connue, l'époque d'une Auvergne très touristique et reconnue pour tout ces bienfaits naturels autant dans nos poumons que dans nos assiettes et nos verres.</p>
                                    </div>
                                    
                                    <div class="col-12 col-md-4 text-md-right">
                                        <a href="edit-page.php?state=edit&page-id=12" class="primary-outline-btn custom-btn mt-1 mb-2">Éditer la page  <i class="icon-pencil"></i></a>
                                        <a href="../../formule.php?page-id=12" class="secondary-outline-btn custom-btn mt-1 mb-2">Voir la page <i class="icon-eye"></i></a>
                                    </div>    
                                    
 
                               </div>
                                                              <div class="row mb-2 mt-2">
                                   
                                    <div class="col-12 col-md-8">
                                        <h2>LE TOUR DE LA HAUTE-LOIRE</h2>
                                        <p>Lac dont le lit est couvert de lauze Donnant un reflet bleu naturel. Non loin du Puy en Velay dans la commune de Champclause ce lac est entouré de nature le tout protégé par la loi. Que ce soit par le contraste et la verdure en été ou le froid et la glace en hiver faisant ressortir le coté minéral ce lac est un des plus beau endroit naturel de la Haute-Loire. Ce lac est le résultat de centaine d'année de pluie et de ruissellement dans une très ancienne cavité servant à extraire une fameuse pierre : la lauze.</p>
                                    </div>
                                    
                                    <div class="col-12 col-md-4 text-md-right">
                                        <a href="edit-page.php?state=edit&page-id=13" class="primary-outline-btn custom-btn mt-1 mb-2">Éditer la page  <i class="icon-pencil"></i></a>
                                        <a href="../../formule.php?page-id=13" class="secondary-outline-btn custom-btn mt-1 mb-2">Voir la page <i class="icon-eye"></i></a>
                                    </div>    
                                    
 
                               </div>
                                                              <div class="row mb-2 mt-2">
                                   
                                    <div class="col-12 col-md-8">
                                        <h2>MONUMENTS EMBLÉMATIQUES</h2>
                                        <p>La chapelle Saint-Michel est une église romane située à Aiguilhe, commune limitrophe du Puy-en-Velay. Elle a été élue 4e monument préféré des français en 2014. L'église est édifiée sur un piton volcanique, le rocher d’Aiguilhe, de 82 mètres de hauteur. La chapelle dédiée à Saint Michel est accessible par un escalier de 268 marches. Selon la légende locale, c'est Gargantua qui donne naissance au rocher d'Aiguilhe. L’évêque Gotescalc, est à l’origine de sa fondation. La première construction, par le chanoine Truanus, remonterait à 969 et remplacerait un temple dédié à Mercure.</p>
                                    </div>
                                    
                                    <div class="col-12 col-md-4 text-md-right">
                                        <a href="edit-page.php?state=edit&page-id=14" class="primary-outline-btn custom-btn mt-1 mb-2">Éditer la page  <i class="icon-pencil"></i></a>
                                        <a href="../../formule.php?page-id=14" class="secondary-outline-btn custom-btn mt-1 mb-2">Voir la page <i class="icon-eye"></i></a>
                                    </div>    
                                    
 
                               </div>
                                                              <div class="row mb-2 mt-2">
                                   
                                    <div class="col-12 col-md-8">
                                        <h2>LE MEZENC</h2>
                                        <p>Localisé à la frontière de l'Ardèche et de la Haute-Loire, le mont Mézenc, dont les deux sommets culminent à 1 744 mètres et 1 753 mètres d'altitude, est situé dans le Parc Naturel Régional des Monts d'Ardèche, sur la ligne de partage des eaux entre l'Atlantique et la Méditerranée, sur les communes de Borée et Les Estables.

D'origine volcanique, ce dôme de phonolite mérite incontestablement d'être gravi. D'une part pour le panorama grandiose sur le Massif central, la vallée du Rhône et les Alpes qu'il délivre depuis la table d'orientation de son sommet Sud. D'autre part pour sa flore exceptionnelle - grande violette des montagnes, séneçon leucophylle, mais aussi arnicas, épilobes, gentianes, anémones, narcisses... - que les promeneurs férus de nature pourront admirer au printemps durant leur ascension.

L'hiver, la station familiale des Estables et l'espace nordique du Mézenc permettent de s'adonner à la pratique du ski de fond, du ski alpin, de la raquette à neige, du snowkite et du traîneau à chiens.

C'est aussi sur le massif du Mézenc que les gastronomes amateurs de viande finement persillée pourront, entre février et juin, déguster le fameux boeuf fin gras du Mézenc, dont la qualité lui vaut d'être estampillé AOC.</p>
                                    </div>
                                    
                                    <div class="col-12 col-md-4 text-md-right">
                                        <a href="edit-page.php?state=edit&page-id=15" class="primary-outline-btn custom-btn mt-1 mb-2">Éditer la page  <i class="icon-pencil"></i></a>
                                        <a href="../../formule.php?page-id=15" class="secondary-outline-btn custom-btn mt-1 mb-2">Voir la page <i class="icon-eye"></i></a>
                                    </div>    
                                    
 
                               </div>
                                                              <div class="row mb-2 mt-2">
                                   
                                    <div class="col-12 col-md-8">
                                        <h2>LES MYSTÈRES DU PUY-EN-VELAY </h2>
                                        <p>Les souterrains du puy: Le cloître du puy en velay et sainte-marie. Ces deux bâtiments ne sont reliés que par un simple point commun: Sous chacun de ces deux lieux connus du Puy en Velay se situe un réseau de couloirs et de caves contenant de nombreuses informations concernant l'héritage de la ville du puy. Les souterrains du cloître vous montrerons l'histoire des channoins et saint-anis. Quant aux souterrains de Sainte-Marie, ils sont aujourd'hui encore remplis de mystères quant à leurs utilités mais la présence d'un cinéma souterrains pourrait supposer qu'il  s'agissait d'une mini ville souterraine pour les résidents de sainte-marie.</p>
                                    </div>
                                    
                                    <div class="col-12 col-md-4 text-md-right">
                                        <a href="edit-page.php?state=edit&page-id=16" class="primary-outline-btn custom-btn mt-1 mb-2">Éditer la page  <i class="icon-pencil"></i></a>
                                        <a href="../../formule.php?page-id=16" class="secondary-outline-btn custom-btn mt-1 mb-2">Voir la page <i class="icon-eye"></i></a>
                                    </div>    
                                    
 
                               </div>
                                                              <div class="row mb-2 mt-2">
                                   
                                    <div class="col-12 col-md-8">
                                        <h2>PAYS DE LA JEUNE LOIRE</h2>
                                        <p>Saint Bonnet le Froid est un village perché à 1 159 m d’altitude entre les plateaux du Velay et du Vivarais et entre les départements de l’Ardèche et de la Haute-Loire. Il marque le point de passage entre, d’un côté, la région Rhône-Alpes et la région Auvergne, et d’un autre côté, entre la Vallée du Rhône et le Massif Central. 
Situé au cœur des forêts de sapins du plateau des Boutières, Saint Bonnet le Froid domine les gorges de la Cance et du Doux. Il est devenu une aire naturelle d’arrêt. 
Nature et gastronomie, telles sont les deux caractéristiques majeures de Saint Bonnet le Froid. Activités de plein air et découverte de la nature se conjuguent avec la cueillette des myrtilles et des champignons. 
Grâce à un emplacement de qualité, Saint Bonnet le Froid est le paradis des randonneurs à pied ou en VTT . Traversé par 3 itinéraires de Grandes Randonnées, 3 circuits de Petites Randonnées, 3 circuits découvertes, un circuit VTT et de nombreux circuits cyclotouristes, le village a su développer "l’esprit nature". 
Et pour ceux qui aiment le patrimoine, vous découvrirez au cours de vos promenades de nombreuses croix, essentiellement des croix de mission et au centre du village une église de style romano-byzantin dont l’intérieur est orné de vitraux 
Après ces balades, prenez le temps de savourer la gastronomie locale. De la cuisine familiale au restaurant de renommée internationale, le village de Saint Bonnet Le Froid se démarque tout particulièrement dans ce domaine. La cuisine du terroir de "nos chefs", à la fois subtile et créative, vous laissera à n’en pas douter un "savoureux" souvenir des Hauts Plateaux du Velay</p>
                                    </div>
                                    
                                    <div class="col-12 col-md-4 text-md-right">
                                        <a href="edit-page.php?state=edit&page-id=17" class="primary-outline-btn custom-btn mt-1 mb-2">Éditer la page  <i class="icon-pencil"></i></a>
                                        <a href="../../formule.php?page-id=17" class="secondary-outline-btn custom-btn mt-1 mb-2">Voir la page <i class="icon-eye"></i></a>
                                    </div>    
                                    
 
                               </div>
                                                              <div class="row mb-2 mt-2">
                                   
                                    <div class="col-12 col-md-8">
                                        <h2>GASTRONOMIE REPUTEE</h2>
                                        <p>Grâce à une cuisine de terroir mais aussi gastronomique, les chefs se distinguent en Haute-Loire. 
Préparez-vous à de succulentes dégustations, autour d’une cuisine traditionnelle mais aussi contemporaine et innovante. 
La cuisine auvergnate est basée sur la qualité des produits locaux. </p>
                                    </div>
                                    
                                    <div class="col-12 col-md-4 text-md-right">
                                        <a href="edit-page.php?state=edit&page-id=18" class="primary-outline-btn custom-btn mt-1 mb-2">Éditer la page  <i class="icon-pencil"></i></a>
                                        <a href="../../formule.php?page-id=18" class="secondary-outline-btn custom-btn mt-1 mb-2">Voir la page <i class="icon-eye"></i></a>
                                    </div>    
                                    
 
                               </div>
                                                              <div class="row mb-2 mt-2">
                                   
                                    <div class="col-12 col-md-8">
                                        <h2>ACTIVITÉS NORDIQUES</h2>
                                        <p>Avec ses grands espaces, ses hauts plateaux, une grande variété de paysages couronnés de panoramas à 360 °, la station village des Estables offre un large panel d’activités dans un décor unique. Ainsi, vous pourrez faire du ski de fond, du ski alpin, du snowboard, du snowkite, du parapente à ski, du patinage, de belles randonnées en raquettes et excursions en chiens de traîneaux. Après une journée riche en émotions et sensations, vous apprécierez d’autant plus les spécialités locales dans une ambiance cosy au coin du feu.</p>
                                    </div>
                                    
                                    <div class="col-12 col-md-4 text-md-right">
                                        <a href="edit-page.php?state=edit&page-id=19" class="primary-outline-btn custom-btn mt-1 mb-2">Éditer la page  <i class="icon-pencil"></i></a>
                                        <a href="../../formule.php?page-id=19" class="secondary-outline-btn custom-btn mt-1 mb-2">Voir la page <i class="icon-eye"></i></a>
                                    </div>    
                                    
 
                               </div>
                                                              
                           </div>
                            
                            
                            
                        </div>
                        
                        
                    </div>
                </div>
                <!-- /.conainer-fluid -->
                
            </main>

        </div>
        

        <footer class="app-footer">
            <span><a href="http://coreui.io">CoreUI</a> © 2017 creativeLabs.</span>
            <span class="ml-auto">Powered by <a href="http://coreui.io">CoreUI</a></span>
        </footer>

        <!-- Bootstrap and necessary plugins -->
        <script src="../../js/popper.js"></script>
        <script src="../../js/bootstrap.min.js"></script>
        <script src="../../js/pace.min.js"></script>

        <!-- CoreUI main scripts -->

        <script src="../js/app.js"></script>

        <!-- Plugins and scripts required by this views -->


    </body>
</html>

